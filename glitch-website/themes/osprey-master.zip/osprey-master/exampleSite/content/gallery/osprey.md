+++
date = "2017-05-15T21:57:17-07:00"
title = "Osprey"
image = "osprey.png"
alt = "Osprey - minimalist blog and portfolio Hugo theme"
color = "#F7F7F7"
link1 = "https://github.com/tomanistor/osprey"
link2 = "https://github.com/tomanistor/osprey"

+++
