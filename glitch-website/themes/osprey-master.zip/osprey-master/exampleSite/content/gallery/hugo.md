+++
date = "2017-05-15T22:25:02-07:00"
title = "Hugo"
image = "hugo.png"
alt = "Hugo - a fast and modern static website engine"
color = "#60d2d3"
link1 = "http://gohugo.io/"
link2 = "https://github.com/spf13/hugo"

+++
