+++
title = "About"
date = "2017-06-27T17:39:21-07:00"
draft = false
+++

## Welcome to the Osprey Theme

To create an about section, generate an about.md file in your content folder by doing:

```console
$ hugo new about.md
```

Then add your own content to the markdown file. Everything in the file will be generated to show here on the home page.
